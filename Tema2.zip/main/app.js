function addTokens(input, tokens)
{
    if(typeof input!=="string")
    {
        throw new Error("Invalid input");
    }
    if(input.length<6)
    {
        throw new Error("Input should have at least 6 characters");
    }
    if(Array.isArray(tokens))
    {
        tokens.forEach((t)=>
        {
            if(typeof t.tokenName!="string")
            {
                throw new Error("Invalid array format");
            }
        });
    }
    if(!input.includes("..."))
    {
        return input;   
    } else
    {
        var newInput;
        tokens.forEach((t) =>
            newInput = input.replace("...", "${" + t.tokenName + "}"));
        return newInput;
    }
}


const app = {
    addTokens: addTokens
}

module.exports = app;